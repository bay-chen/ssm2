package com.zzl.service;

import java.util.Date;

public class Log{
	public void writeLog() {
		System.out.println("日志信息:猫抓到了老鼠，时间："+new Date().toLocaleString());
	}
}
