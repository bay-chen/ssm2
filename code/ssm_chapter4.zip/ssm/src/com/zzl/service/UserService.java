package com.zzl.service;

import com.zzl.pojo.UserInfo;

public interface UserService {
	
	UserInfo findById(Integer id);
	UserInfo findById2(Integer id);
	void insertUserInfo(UserInfo user);

}
