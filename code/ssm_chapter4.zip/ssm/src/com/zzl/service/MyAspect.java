package com.zzl.service;

import org.springframework.stereotype.Component;

public class MyAspect {
	
		private String name;	
		public void catchMouse(Mouse m,String loc){
	            //猫抓老鼠的业务逻辑代码
			System.out.println(name+"猫抓到了老鼠"+m.getName());
		}
	
}
