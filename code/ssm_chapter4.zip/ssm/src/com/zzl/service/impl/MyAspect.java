package com.zzl.service.impl;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAspect {
	
	@Pointcut("execution(* com.zzl.service.impl..*(..))")
	public void allServiceMethod() {}
	
	@Before("execution(* com.zzl.service.impl..*(..))")
	public void before() {
		System.out.println("public void before()");
	}
	
	@After("allServiceMethod()")
	public void after() {
		System.out.println("public void after()");
	}
	public  MyAspect() {
		System.out.println("--------public  MyAspect() -----------");
	}	
}
