package com.zzl.service.impl;

public class ServiceLog {
	
	public void before() {
		System.out.println("before advice");
	}

	public void after() {
		System.out.println("after advice");
	}
}
