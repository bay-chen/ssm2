package com.zzl.service.impl;

public interface TestService {

	void save();

}