package com.zzl.service.impl;

import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements TestService {
	
	public  TestServiceImpl() {

		System.out.println("--------public  TestServiceImpl()----------");
	}
	@Override
	
	public void save() {
		System.out.println("-------public void save()---------");
	}
}
