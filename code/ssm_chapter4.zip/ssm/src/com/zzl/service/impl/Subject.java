package com.zzl.service.impl;

public interface Subject {
	void doSomething();
}
