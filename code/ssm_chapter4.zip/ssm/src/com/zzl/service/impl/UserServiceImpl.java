package com.zzl.service.impl;

import static org.junit.jupiter.api.Assertions.fail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.zzl.dao.UserInfoDao;
import com.zzl.pojo.UserInfo;
import com.zzl.service.UserService;

/*@Transactional(readOnly = true)
@Service("userService")*/
public class UserServiceImpl implements UserService {

	@Autowired
	private UserInfoDao userInfoDao;

	public UserInfo findById(Integer id) {
	
		return userInfoDao.findById(id);

	}

	public UserServiceImpl() {

		System.out.println("---------public  UserServiceImpl()--------");

	}

	@Transactional(readOnly = false)
	public void insertUserInfo(UserInfo user) {
		userInfoDao.insertUserInfo(user);
	}

	@Override
	public UserInfo findById2(Integer id) {
		return userInfoDao.findById2(id);
	}
}
