package com.zzl.service;

import org.springframework.stereotype.Service;

@Service
public class Cat {
	private String name;
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void catchMouse(Mouse m,String loc){
           //猫抓老鼠的业务逻辑代码
		System.out.println(name+"猫抓到了老鼠"+m.getName());
		}


}
