package com.zzl.test;

import com.zzl.service.impl.CglibDynamicProxy;
import com.zzl.service.impl.RealSubject;

public class CglibTest {

	public static void main(String[] args) {
		
		RealSubject realSubject = new RealSubject();
		CglibDynamicProxy cglibDynamicProxy = new CglibDynamicProxy(realSubject);
		RealSubject proxy = (RealSubject) cglibDynamicProxy.getProxy(realSubject);
		proxy.doSomething();

	}

}
