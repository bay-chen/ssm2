package com.zzl.test;

import com.zzl.service.impl.JDKDynamicProxy;
import com.zzl.service.impl.RealSubject;
import com.zzl.service.impl.Subject;

public class Client {

	public static void main(String[] args) {
	
		 Subject subject = new JDKDynamicProxy(new RealSubject()).getProxy();
	        subject.doSomething();

	}

}
