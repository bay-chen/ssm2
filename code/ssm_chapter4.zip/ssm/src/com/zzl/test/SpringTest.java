package com.zzl.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.zzl.pojo.UserInfo;
import com.zzl.service.Cat;
import com.zzl.service.Mouse;
import com.zzl.service.UserService;
import com.zzl.service.impl.MyAspect;
import com.zzl.service.impl.TestService;
import com.zzl.service.impl.TestServiceImpl;

public class SpringTest {

	public static void main(String[] args) throws Exception {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans-tx.xml");
		/*
		 * UserService userService = (UserService) context.getBean("userService");
		 * UserInfo userInfo = userService.findById2(1); System.out.println(userInfo);
		 */
		
		TestService bean = context.getBean(TestService.class);
		bean.save();
		
	}

}
