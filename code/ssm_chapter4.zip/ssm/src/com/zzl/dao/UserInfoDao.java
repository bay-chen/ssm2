package com.zzl.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.zzl.pojo.UserInfo;

public interface UserInfoDao {

	UserInfo findById(Integer id);
	
	@Select("select * from userinfo where id=#{id}")
	@Results({
		@Result(column = "id",property = "id",javaType = Integer.class),
		@Result(column = "username",property = "username"),
		@Result(column = "password",property = "password")
	})
	UserInfo findById2(Integer id);
	
	@Insert(value = "insert into userinfo(username,password) values(#{username},#{password})")
	@Options(keyColumn = "id",keyProperty = "id",useGeneratedKeys = true)
	void insertUserInfo(UserInfo user);
}
