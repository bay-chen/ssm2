package com.ssm.chapter4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Director {

	public static void main(String[] args) {
		//创建Spring容器对象
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		//获取MoAttack（墨攻电影）对象
		MoAttack moAttack = context.getBean(MoAttack.class,"moAttack");
		moAttack.cityGateAsk();//城门叩问场景
	}

}
