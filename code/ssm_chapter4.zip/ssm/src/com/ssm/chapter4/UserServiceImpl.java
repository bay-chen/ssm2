package com.ssm.chapter4;

import org.springframework.beans.factory.annotation.Autowired;

public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;
	@Override
	public void save(User user) {
		userDao.save(user);
	}
	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	public UserServiceImpl(UserDao userDao) {
		this.userDao = userDao;
	}
	public UserServiceImpl() {
		
	}
}
