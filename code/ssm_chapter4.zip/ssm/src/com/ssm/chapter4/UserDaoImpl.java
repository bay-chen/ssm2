package com.ssm.chapter4;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

public class UserDaoImpl implements UserDao {

	@Override
	public void save(User user) {		
		System.out.println("save user:"+user);	
	}

}
