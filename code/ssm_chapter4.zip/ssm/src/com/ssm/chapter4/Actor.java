package com.ssm.chapter4;

public class Actor implements GeLi {
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public void responseAsk(String s) {	
		System.out.println("我是"+s);
	}
}
