package com.ssm.chapter4;

public class MoAttack {

	private GeLi geLi;

	
	public MoAttack(GeLi geLi) {
		this.geLi = geLi;
	}

	public void cityGateAsk() {
		geLi.responseAsk("墨者革离");
	}

}
