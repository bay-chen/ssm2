package com.ssm.chapter4;

import org.springframework.beans.factory.annotation.Autowired;

public class UserAction {
	@Autowired
	private UserService userService;
	
	public void save() {
		User user = new User("zhangsan", "123456");
		userService.save(user);
	}

}
