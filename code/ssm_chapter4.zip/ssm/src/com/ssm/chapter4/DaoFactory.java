package com.ssm.chapter4;

public class DaoFactory {
	
	public static UserDao getUserDaoImpl(){
		return new UserDaoImpl();
	}

}
