package com.ssm.chapter4;

public interface UserService {
	public void save(User user);

}
