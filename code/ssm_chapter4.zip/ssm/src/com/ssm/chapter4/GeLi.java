package com.ssm.chapter4;

public interface GeLi {
	
	 void responseAsk(String s);

}
