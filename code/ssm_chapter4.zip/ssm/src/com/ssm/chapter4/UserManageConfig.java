package com.ssm.chapter4;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration//@Configuration用于定义配置类，可替换xml配置文件
@ComponentScan("com.ssm.chapter4")
public class UserManageConfig {
	@Bean
	public UserDao getUserDao() {
		return new UserDaoImpl();
	}
	@Bean
	public UserService getUserService() {
		return new UserServiceImpl();
	}
	@Bean
	public UserAction getUserAction() {
		return new UserAction();
	}
}
