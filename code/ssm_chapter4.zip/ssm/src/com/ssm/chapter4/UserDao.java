package com.ssm.chapter4;

public interface UserDao {
	
	public void save(User user);

}
